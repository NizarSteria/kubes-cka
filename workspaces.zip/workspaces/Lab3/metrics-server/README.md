The components.yaml file comes from the [metrics-server](https://github.com/kubernetes-sigs/metrics-server) repo.
This is the vanilla v0.6.1 release which we added the `--kubelet-insecure-tls` parameter to the metrics-server pod template.
